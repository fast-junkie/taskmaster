package local.cybertron.taskmaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskmasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
